<?php
include_once('./config/DatabaseProces.php');

$products = New DatabaseProcess();
$products -> getAll();
$results = $products -> getAll();
$products -> getventas();
$ventas2 = $products -> getventas();
$products -> getclientes();
$clientes = $products -> getclientes();
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Vista Administrador</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/grid/">

    

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="grid.css" rel="stylesheet">
  </head>
  <body class="py-4" style="background-color:#faf0e6">
    
<main>
  <div class="container">
  <center><strong><h1 style="font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;">VISTA ADMINISTRADOR</h1></strong></center>
  <center><p>Esta vista permitira ver listado, añadir, editar y eliminar</p></center>
  <br>
    <nav class="background-color:#faf0e6">
      <div class="container-fluid">
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Buscar">
          <button class="w-60 btn btn-outline-secondary btn-lg"> Buscar</button>
        </form>
      </div>
    </nav>
  <br>

  <strong class="mt-4">PRODUCTOS</strong>
  <br>

  <div class="row mb-2">
    <div class="col-2 themed-grid-col"><strong><center>Id</center></strong></div>
    <div class="col-2 themed-grid-col"><strong><center>Nombre</center></strong></div>
    <div class="col-2 themed-grid-col"><strong><center>Tipo</center></strong></div>
    <div class="col-2 themed-grid-col"><strong><center>Precio</center></strong></div>
    <div class="col-4 themed-grid-col"><strong><center>Descripcion</center></strong></div>
  </div>

  <?php
  foreach($results as $result) {
    echo "<div class='row mb-2'>
    
    <div class='col-sm-2 themed-grid-col'>".$result->id."</div>
    <div class='col-sm-2 themed-grid-col'>".$result->nombre."</div>
    <div class='col-sm-2 themed-grid-col'>".$result->tipo."</div>
    <div class='col-sm-2 themed-grid-col'>".$result->precio."</div>
    <div class='col-sm-4 themed-grid-col'>".$result->descripcion."</div>

    </div>";

  }
  ?>
  
    <footer class="text-muted py-5">
      <div class="container">
        <p class="float-end mb-1">
          <a class="w-60 btn btn-outline-secondary btn-lg" href="añadirp.php">Añadir</a>
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Editarp.php">Editar</a>
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Eliminarp.php">Eliminar</a>
        </p>
      </div>
    </footer>
    <br>


    <strong class="mt-4">VENTAS</strong>
    <br>

    <div class="row mb-2">
    <div class="col-4 themed-grid-col"><strong><center>Id</center></strong></div>
    <div class="col-4 themed-grid-col"><strong><center>Producto</center></strong></div>
    <div class="col-4 themed-grid-col"><strong><center>Precio</center></strong></div>
  </div>
   
    <?php
  foreach($ventas2 as $ventas) {
    echo "<div class='row mb-2'>
    
    <div class='col-sm-4 themed-grid-col'>".$ventas->id."</div>
    <div class='col-sm-4 themed-grid-col'>".$ventas->producto."</div>
    <div class='col-sm-4 themed-grid-col'>".$ventas->valor_producto."</div>

    </div>";

  }
  ?>

    <footer class="text-muted py-5">
      <div class="container">
        <p class="float-end mb-1">
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Añadirv.php">Añadir</a>
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Editarv.php">Editar</a>
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Eliminarv.php">Eliminar</a>
        </p>
      </div>
    </footer>
    <br>

    <strong class="mt-4">CLIENTES</strong>
    <br>
    <div class="row mb-2">
      <div class="col-4 themed-grid-col"><strong><center>Id</center></strong></div>
      <div class="col-4 themed-grid-col"><strong><center>Nombre</center></strong></div>
      <div class="col-4 themed-grid-col"><strong><center>identificacion</center></strong></div>
    </div>

    <?php
  foreach($clientes as $cliente) {
    echo "<div class='row mb-2'>
    
    <div class='col-sm-4 themed-grid-col'>".$cliente->id."</div>
    <div class='col-sm-4 themed-grid-col'>".$cliente->nombre."</div>
    <div class='col-sm-4 themed-grid-col'>".$cliente->identificacion."</div>

    </div>";

  }
  ?>


    <footer class="text-muted py-5">
      <div class="container">
        <p class="float-end mb-1">
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Añadirc.php">Añadir</a>
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Editarc.php">Editar</a>
          <a class="w-60 btn btn-outline-secondary btn-lg" href="Eliminarc.php">Eliminar</a>
        </p>
      </div>
    </footer>
    <br>
  </div>
</main>    
  </body>
</html>
