<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>AROMA CAFETERO</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/album/">

    

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
  </head>
  <body class="py-4" style="background-color:#faf0e6">
    
<header>
  <div class="collapse bg-dark" id="navbarHeader" >
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-md-7 py-4">
          <h4 class="text-white">Sobre nosotros</h4>
          <p class="text-muted">Somos un espacio donde puedes venir a disfrutar con tus amigos y familia esos momentos unicos e inolvidables con la compañia de nuestros deliciosos cafes.</p>
        </div>
        <div class="col-sm-4 offset-md-1 py-4">
          <h4 class="text-white">Contactanos</h4>
          <ul class="list-unstyled">
            <li><a href="#" class="text-white">314 657 8900</a></li>
            <li><a href="#" class="text-white">606 878 7634</a></li>
            <li><a href="#" class="text-white">aroma.cafetero@mail.com</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container">
      <a href="#" class="navbar-brand d-flex align-items-center">
        <strong>AROMA CAFETERO</strong>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </div>
</header>

<main>

  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1><strong>Delicias y más</strong></h1>
        <p class="lead text-muted">Ven a disfrutar de un lugar lleno de aromas de nuestra tierra</p>
        <p>
          <a href="login.php" class="w-100 btn btn-outline-secondary btn-lg">Iniciar sesion</a></p>
      </div>
    </div>
  </section>

  <div class="album py-5 bg-light">
    <div class="container">
      <strong>Café</strong>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.elespectador.com/resizer/L_d9v6uuxjkcZkONzjrpOAr9Lus=/arc-anglerfish-arc2-prod-elespectador/public/3RLSJX3IBNA55F5OZPNWSLSGQE.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>CAPUCHINO</strong>
              <p class="card-text">Es una bebida nacida en Italia, preparada con café expreso y leche montada con vapor para darle cremosidad.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.comedera.com/wp-content/uploads/2022/09/Mocaccino-shutterstock_2086443826.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225">

            <div class="card-body">
              <strong>MOCACCINO</strong>
              <p class="card-text">Suele llevar un tercio de expreso y dos tercios de leche vaporizada, pero se añade una parte de chocolate.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://comohacercafe.com/wp-content/uploads/2020/03/espresso.jpeg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>EXPRESSO</strong>
              <p class="card-text">Se caracteriza por su rápida preparación a una alta presión y por un sabor y textura más concentrados.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.recetasderechupete.com/wp-content/uploads/2022/01/Latte-macchiato.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>MACCHIATO</strong>
              <p class="card-text"> es un café cortado típico de Italia, consiste en un expreso con una pequeña cantidad de leche caliente y espumada</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://primerocafe.com.mx/wp-content/uploads/2019/10/receta-para-preparar-cafe-ristretto.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>RISTRETTO</strong>
              <p class="card-text">Se elabora con la misma cantidad de café molido, pero se extrae con un molido más fino utilizando la mitad de agua</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://dairyfarmersofcanada.ca/sites/default/files/image_file_browser/conso_recipe/2021/Cafe%20Latte.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>LATTE</strong>
              <p class="card-text">Es una bebida de café de origen italiano hecha con espresso y leche al vapor. a menudo abreviado simplemente como latte</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="https://cdn.elcocinerocasero.com/imagen/receta/1000/2022-10-24-18-04-45/cafe-irlandes.jpeg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>IRLANDES</strong>
              <p class="card-text">Consiste en la mezcla de whisky irlandés, una cucharada de azúcar y café, pero finalmente va cubierto de crema de leche</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://imag.bonviveur.com/carajillo.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>CARAJILLO</strong>
              <p class="card-text">Bebida que combina café y alguna bebida alcohólica, como coñac, ron, anís, orujo o whisky.​ </p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://comohacercafe.com/wp-content/uploads/2022/06/como-se-hace-un-cortado-en-maquina.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>CORTADO</strong>
              <p class="card-text">Forma en que leche “corta” la intensidad del espresso, atenuando su acidez mientras mantiene el sabor del café.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$5.000</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="album py-5 bg-light">
    <div class="container">
      <strong>Postres</strong>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.recetasnestle.com.ec/sites/default/files/srh_recipes/7f45d6f8807ebc775928651a3398dce9.png" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>TIRAMISÚ</strong>
              <p class="card-text">Postre italiano derivado de 'tira mi su', que traducido significa algo así como 'levántame el ánimo'.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 7.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.santaelena.com.co/wp-content/uploads/2021/04/cheesecake-de-fresa.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>CHEESECAKE</strong>
              <p class="card-text">El Cheesecake o tarta de queso es un postre muy popular desde el siglo XX hecho a base de ricota, requesón, queso quark.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 6.500</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://images.aws.nestle.recipes/original/0449a8c25afa3f08557c770e42cf8759_receta-intermedia-familiar-cupcakes-de-chocolate-y-crema-de-cafe-recetas-nestle-venezuela-savoy-receta-naviden%CC%83a.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>CUPCAKE</strong>
              <p class="card-text"> es una pequeña tarta proporcionado para una persona. Se hornean en un molde igual que el de magdalenas y muffins.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 4.500</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.recetasnestle.com.ve/sites/default/files/srh_recipes/e2928ff551a360cdadb4e5a2528841b7.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>TORTA DE CHOCOLATE</strong>
              <p class="card-text">Es un postre conocido internacionalmente, que se popularizó a finales del siglo XIX y se sirve frecuentemente en reuniones</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 6.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.annarecetasfaciles.com/files/tarta-de-zanahoria.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>TORTA DE ZANAHORIA</strong>
              <p class="card-text">Tarta de zanahoria o torta de zanahoria es un pastel dulce con zanahoria machacada mezclada en la masa.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 5.500</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://cuk-it.com/wp-content/uploads/2021/07/thumb03-1-1024x576.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>DONAS</strong>
              <p class="card-text"> Dónut​​​, rosquilla, rosquita, rosqueta, rosca, berlina o berlín, es una rosca de pan dulce que tradicionalmente está frito</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 3.500</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="album py-5 bg-light">
    <div class="container">
      <strong>Cervezas</strong>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://1000marcas.net/wp-content/uploads/2019/12/Corona-Extra-Log%D0%BE-1.png" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>CORONA</strong>
              <p class="card-text">Es una bebida del tipo pilsener que comenzó a elaborarse en el año de 1925, en la planta de la Cervecería Modelo</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 6.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://tiendasyaco.vtexassets.com/assets/vtex.file-manager-graphql/images/7445aaf4-83ba-446f-8e4b-9f87e31404c7___281e98aa8a0563e56af59d59696ad4b6.png" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>PILSEN</strong>
              <p class="card-text">Marca más antigua del portafolio de cervezas, desde 1904 ha representado el orgullo paisa al ser la marca líder de la región antioqueña</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://storage.googleapis.com/www-paredro-com/uploads/2019/08/8fe2fdd3-logo-de-heineken.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>HEINEKEN</strong>
              <p class="card-text">Conocida simplemente como Heineken, es una cerveza con 5,0 % alc. vol., elaborada por la cervecería neerlandesa Heineken</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 6.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://3cordilleras.com/wp-content/uploads/2020/09/Logo-Blanco.png" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>TRES CORDILLERAS</strong>
              <p class="card-text">Está cargada de maltas tostadas, oscuras y acarameladas, quien se caracteriza por su aroma a café y cocoa</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 8.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://i0.wp.com/www.elpoderdelasideas.com/wp-content/uploads/budweiser_2016_logo-600x338.jpg?resize=600%2C338" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>BUDWEISER</strong>
              <p class="card-text">Se perciben ligeras notas afrutadas a plátano y frutas maduras, con aromas menos intensos a grano tostado y caramelo</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 5.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJr7sX0r_WxZsGm2jWMQa4HhJ6rDi3Kj9mVQ&usqp=CAU" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>REDD´S</strong>
              <p class="card-text">Cerveza polaca, sabor arandano. En aroma frutos rojos, manzana y sirope. De sabor dulce, afrutado con ligera y refrescante acidez</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 6.000</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="album py-5 bg-light">
    <div class="container">
      <strong>Cócteles</strong>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.mundocuervo.com/media/2145/blog.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>MARGARITA</strong>
              <p class="card-text">Compuesto por tequila, triple seco y jugo de lima o limón. A menudo se sirve con sal en el borde de la copa.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 10.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.clarin.com/img/2021/08/06/ZxCQ0Sd1g_1200x630__1.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>MOJITO</strong>
              <p class="card-text">El mojito​ es un cóctel popular originario de Cuba, compuesto de ron, limón, azúcar, menta o eucalipto y agua mineral</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 12.500</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.clarin.com/img/2022/10/18/el-gin-tonic-un-trago___u4ByxxiYX_2000x1500__1.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>GINTONIC</strong>
              <p class="card-text">Es un cóctel compuesto de ginebra y agua tónica servida con hielo, en unas proporciones sugeridas de 1:1, 1:2, 1:3 y 2:3</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 13.500</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.recetasderechupete.com/wp-content/uploads/2021/08/Manhattan-1.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>MANHATTAN</strong>
              <p class="card-text">El Manhattan es un cóctel clásico a base de whiskey y vermut rojo, que se suele tomar como aperitivo.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 12.000</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.comedera.com/wp-content/uploads/2022/05/martini.jpg" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>MARTINI</strong>
              <p class="card-text">Compuesto de ginebra con una porción de vermut. Suele servirse en copa de cóctel, adornado con una aceituna cruzada.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 12.500</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.goya.com/media/6962/pina-colada.png?quality=80" alt="" class="bd-placeholder-img card-img-top" width="100%" height="225"> 

            <div class="card-body">
              <strong>PIÑA COLADA</strong>
              <p class="card-text">La piña colada es una bebida cuyos ingredientes principales son la piña, la crema de coco y el ron, cuenta con 14,9% de alcohol.</p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">$ 15.000</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<footer class="text-muted py-5">
  <div class="container">
    <p class="float-end mb-1">
      <a href="#">Volver al inicio</a>
    </p>
    <a href="https://www.google.com/maps/dir//Cra.+23+%2326-57,+Manizales,+Caldas/@5.067312,-75.5845324,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x8e476ff0c76b9723:0x30ef443d80753a96!2m2!1d-75.5144918!2d5.0673159">¿Donde nos ubicamos?</a></p>
  </div>
</footer>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>