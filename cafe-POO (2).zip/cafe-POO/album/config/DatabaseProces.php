<?php


include_once('db.php');


class DatabaseProcess extends DatabasePDO
{

    private $user;
    private $pass;

    public function getAll()
    {
        try {
            
            # Conexión a MySQL
            // Instantiate database.
            $cnn = $this->conn();
            //Preparamos la consulta sql
              $respuesta = $cnn->prepare("select * from productos");
              //Ejecutamos la consulta
              $respuesta->execute();
              
              $productos = $respuesta ->fetchAll(PDO::FETCH_OBJ);
        }
        catch(PDOException $e) {
            echo $e->getMessage();
        }
        return $productos;
    }


    public function getventas()
    {
        try {
            
            # Conexión a MySQL
            // Instantiate database.
            $cnn = $this->conn();
            //Preparamos la consulta sql
              $respuesta = $cnn->prepare("select * from ventas");
              //Ejecutamos la consulta
              $respuesta->execute();
              
              $ventas = $respuesta ->fetchAll(PDO::FETCH_OBJ);
        }
        catch(PDOException $e) {
            echo $e->getMessage();
        }
        return $ventas;
    }

    public function getclientes()
    {
        try {
            
            # Conexión a MySQL
            // Instantiate database.
            $cnn = $this->conn();
            //Preparamos la consulta sql
              $respuesta = $cnn->prepare("select * from clientes");
              //Ejecutamos la consulta
              $respuesta->execute();
              
              $clientes = $respuesta ->fetchAll(PDO::FETCH_OBJ);
        }
        catch(PDOException $e) {
            echo $e->getMessage();
        }
        return $clientes;
    }

    public function store(){
        try {

           # Conexión a MySQL
           // Instantiate database.
           $cnn = $this->conn();
           //Preparamos la consulta sql
           $stmt = $cnn->prepare("INSERT INTO clientes(nombre, documento) values(:nombre,:documento)");
           $stmt->bindParam(":nombre", $this->user, PDO::PARAM_STR);
           $stmt->bindParam(":documento", $this->pass, PDO::PARAM_STR);
           $stmt->execute();

           $lastInsertId = $cnn->lastInsertId();

$mensaje='';
if($lastInsertId>0){
   $mensaje='insertado';

} 
else{$mensaje='error';}   
           

       } catch (PDOException $e) {
           echo $e->getMessage();
       }
       return $mensaje;


   }



    public function login($user,$pass)
    {
        try {
            
            $this->user=$user;
            $this->pass=$pass;

            # Conexión a MySQL
            // Instantiate database.
            $cnn = $this->conn();
        
                //Preparamos la consulta sql
                $stmt = $cnn->prepare("SELECT * FROM administrador WHERE usuario=:usernameEmail  AND contrasena=:hash_password"); 
                $stmt->bindParam("usernameEmail", $this->user,PDO::PARAM_STR) ;
                $stmt->bindParam("hash_password", $this->pass,PDO::PARAM_STR) ;
                //Ejecutamos la consulta
                $stmt->execute();
                $count=$stmt->rowCount();
                $data=$stmt->fetch(PDO::FETCH_OBJ);
                $db = null;
                $mesage= "";
                if($count)
                {
                
                    $mesage = "verdadero";
                }
                else
                {
                    $mesage = "Falso";


                } 
                }
                catch(PDOException $e) {
                echo '{"error":{"text":'. $e->getMessage() .'}}';
                }
                return $mesage;
    }

}